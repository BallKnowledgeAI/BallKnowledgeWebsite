'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@supabase/supabase-js'
import { Sun, Moon, Github, Linkedin, Eye, Brain, Zap } from 'lucide-react'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null

const BallKnowledge = () => {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')
  const [mounted, setMounted] = useState(false)
  const [email, setEmail] = useState('')
  const [emailError, setEmailError] = useState('')
  const [emailSuccess, setEmailSuccess] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [countdown, setCountdown] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 })
  const [draggedDot, setDraggedDot] = useState<string | null>(null)
  const [dotOffsets, setDotOffsets] = useState<{ [key: string]: { x: number; y: number } }>({})

  useEffect(() => {
    setMounted(true)
    const stored = (localStorage.getItem('bk-theme') as 'dark' | 'light') || 'dark'
    setTheme(stored)
    document.documentElement.setAttribute('data-theme', stored)
  }, [])

  useEffect(() => {
    const updateCountdown = () => {
      const target = new Date('2026-09-01T00:00:00Z').getTime()
      const now = new Date().getTime()
      const diff = target - now

      if (diff <= 0) {
        setCountdown({ days: 0, hours: 0, minutes: 0, seconds: 0 })
        return
      }

      setCountdown({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((diff / 1000 / 60) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      })
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [])

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark'
    setTheme(newTheme)
    localStorage.setItem('bk-theme', newTheme)
    document.documentElement.setAttribute('data-theme', newTheme)
  }

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setEmailError('')
    setEmailSuccess(false)

    if (!email.trim()) {
      setEmailError('Email is required')
      return
    }

    if (!validateEmail(email)) {
      setEmailError('Please enter a valid email')
      return
    }

    if (!supabase) {
      setEmailError('Service not configured')
      return
    }

    setIsSubmitting(true)

    try {
      const { error } = await supabase.from('waitlist').insert([
        {
          email: email.toLowerCase().trim(),
          source: 'ballknowledge-coming-soon',
        },
      ])

      if (error) {
        if (error.code === '23505') {
          setEmailError('Already on the list!')
        } else {
          setEmailError('Something went wrong. Try again.')
        }
      } else {
        setEmailSuccess(true)
        setEmail('')
        setTimeout(() => setEmailSuccess(false), 3000)
      }
    } catch {
      setEmailError('Something went wrong. Try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDotPointerDown = (dotId: string, e: React.PointerEvent) => {
    setDraggedDot(dotId)
    const svg = (e.target as SVGCircleElement).ownerSVGElement
    if (!svg) return
    const rect = svg.getBoundingClientRect()
    const startX = e.clientX - rect.left
    const startY = e.clientY - rect.top

    const handlePointerMove = (moveEvent: PointerEvent) => {
      if (!svg) return
      const rect = svg.getBoundingClientRect()
      const currentX = moveEvent.clientX - rect.left
      const currentY = moveEvent.clientY - rect.top
      const dx = currentX - startX
      const dy = currentY - startY
      setDotOffsets((prev) => ({
        ...prev,
        [dotId]: { x: dx, y: dy },
      }))
    }

    const handlePointerUp = () => {
      document.removeEventListener('pointermove', handlePointerMove)
      document.removeEventListener('pointerup', handlePointerUp)
      document.removeEventListener('pointercancel', handlePointerUp)
      setDraggedDot(null)
      setTimeout(() => {
        setDotOffsets((prev) => ({
          ...prev,
          [dotId]: { x: 0, y: 0 },
        }))
      }, 50)
    }

    document.addEventListener('pointermove', handlePointerMove)
    document.addEventListener('pointerup', handlePointerUp)
    document.addEventListener('pointercancel', handlePointerUp)
  }

  if (!mounted) return null

  // Pitch formations
  const teamA = [
    { x: 120, y: 375 }, // GK
    { x: 240, y: 200 }, // Defenders
    { x: 240, y: 320 },
    { x: 240, y: 430 },
    { x: 240, y: 550 },
    { x: 420, y: 240 }, // Midfielders
    { x: 420, y: 375 },
    { x: 420, y: 510 },
    { x: 560, y: 180 }, // Forwards
    { x: 560, y: 375 },
    { x: 560, y: 570 },
  ]

  const teamB = [
    { x: 1080, y: 375 }, // GK
    { x: 960, y: 200 }, // Defenders
    { x: 960, y: 320 },
    { x: 960, y: 430 },
    { x: 960, y: 550 },
    { x: 780, y: 160 }, // Midfielders
    { x: 780, y: 320 },
    { x: 780, y: 430 },
    { x: 780, y: 590 },
    { x: 640, y: 310 }, // Strikers
    { x: 640, y: 440 },
  ]

  const passLines = [
    { x1: 240, y1: 200, x2: 420, y2: 240, id: 'p1' },
    { x1: 420, y1: 375, x2: 560, y2: 375, id: 'p2' },
    { x1: 240, y1: 550, x2: 420, y2: 510, id: 'p3' },
    { x1: 560, y1: 180, x2: 780, y2: 160, id: 'p4' },
    { x1: 420, y1: 240, x2: 560, y2: 180, id: 'p5' },
    { x1: 560, y1: 570, x2: 780, y2: 590, id: 'p6' },
  ]

  return (
    <div
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        backgroundColor: 'var(--bg)',
        color: 'var(--text)',
        fontFamily: 'var(--font-dm-sans)',
        zIndex: 10,
      }}
    >
      {/* Background gradients */}
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
          zIndex: 0,
        }}
      >
        <div
          style={{
            position: 'absolute',
            width: '60vw',
            height: '60vh',
            left: '30%',
            top: '40%',
            background: theme === 'light'
              ? 'radial-gradient(ellipse, rgba(31,60,136,0.12) 0%, transparent 70%)'
              : 'radial-gradient(ellipse, rgba(31,60,136,0.28) 0%, transparent 70%)',
            filter: 'blur(40px)',
            borderRadius: '50%',
          }}
        />
        <div
          style={{
            position: 'absolute',
            width: '50vw',
            height: '50vh',
            left: '70%',
            top: '60%',
            background: theme === 'light'
              ? 'radial-gradient(ellipse, rgba(59,167,240,0.1) 0%, transparent 70%)'
              : 'radial-gradient(ellipse, rgba(59,167,240,0.18) 0%, transparent 70%)',
            filter: 'blur(40px)',
            borderRadius: '50%',
          }}
        />
        <div
          style={{
            position: 'absolute',
            width: '40vw',
            height: '40vh',
            left: '50%',
            top: '25%',
            transform: 'translateX(-50%)',
            background: 'radial-gradient(ellipse, rgba(46,204,113,0.06) 0%, transparent 70%)',
            filter: 'blur(40px)',
            borderRadius: '50%',
          }}
        />
      </div>

      {/* Pitch Background */}
      <svg
        viewBox="0 0 1200 750"
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          zIndex: 0,
          pointerEvents: 'none',
        }}
        preserveAspectRatio="xMidYMid slice"
      >
        {/* Pitch surface */}
        <rect x="0" y="0" width="1200" height="750" fill="var(--pitch-fill)" />

        {/* Pitch outline */}
        <rect x="80" y="50" width="1040" height="650" fill="none" stroke="var(--pitch-line)" strokeWidth="1.5" />

        {/* Halfway line */}
        <line x1="600" y1="50" x2="600" y2="700" stroke="var(--pitch-line)" strokeWidth="1.5" />

        {/* Center circle */}
        <circle cx="600" cy="375" r="100" fill="none" stroke="var(--pitch-line)" strokeWidth="1.5" />
        <circle cx="600" cy="375" r="6" fill="var(--primary)" opacity="0.5" />

        {/* Attacking third shading */}
        <rect x="940" y="50" width="180" height="650" fill="rgba(59,167,240,0.03)" />
        <rect x="80" y="50" width="180" height="650" fill="rgba(46,204,113,0.03)" />

        {/* Vertical channel lines */}
        <line x1="280" y1="50" x2="280" y2="700" stroke="rgba(255,255,255,0.04)" strokeWidth="1" strokeDasharray="4 6" />
        <line x1="460" y1="50" x2="460" y2="700" stroke="rgba(255,255,255,0.04)" strokeWidth="1" strokeDasharray="4 6" />
        <line x1="740" y1="50" x2="740" y2="700" stroke="rgba(255,255,255,0.04)" strokeWidth="1" strokeDasharray="4 6" />
        <line x1="920" y1="50" x2="920" y2="700" stroke="rgba(255,255,255,0.04)" strokeWidth="1" strokeDasharray="4 6" />

        {/* Heatmap zones - pressure zones */}
        <ellipse cx="240" cy="180" rx="140" ry="100" fill="url(#heatmapGradient1)" />
        <ellipse cx="600" cy="375" rx="180" ry="140" fill="url(#heatmapGradient2)" />
        <ellipse cx="900" cy="500" rx="150" ry="110" fill="url(#heatmapGradient3)" />

        {/* Green zones - scoring areas */}
        <ellipse cx="150" cy="375" rx="90" ry="110" fill={theme === 'light' ? 'rgba(46,204,113,0.12)' : 'rgba(46,204,113,0.08)'} />
        <ellipse cx="1050" cy="375" rx="90" ry="110" fill={theme === 'light' ? 'rgba(46,204,113,0.12)' : 'rgba(46,204,113,0.08)'} />

        {/* Gradient definitions */}
        <defs>
          <radialGradient id="heatmapGradient1">
            <stop offset="0%" stopColor="rgba(59,167,240,0.12)" />
            <stop offset="100%" stopColor="rgba(59,167,240,0)" />
          </radialGradient>
          <radialGradient id="heatmapGradient2">
            <stop offset="0%" stopColor="rgba(59,167,240,0.12)" />
            <stop offset="100%" stopColor="rgba(59,167,240,0)" />
          </radialGradient>
          <radialGradient id="heatmapGradient3">
            <stop offset="0%" stopColor="rgba(59,167,240,0.12)" />
            <stop offset="100%" stopColor="rgba(59,167,240,0)" />
          </radialGradient>
        </defs>

        {/* Left penalty area */}
        <rect x="80" y="165" width="180" height="420" fill="none" stroke="var(--pitch-line)" strokeWidth="1.5" />
        <rect x="80" y="270" width="60" height="210" fill="none" stroke="var(--pitch-line)" strokeWidth="1.5" />
        <circle cx="150" cy="375" r="4" fill="var(--primary)" opacity="0.5" />
        <path d="M 140 165 Q 80 240 80 375 Q 80 510 140 585" fill="none" stroke="var(--pitch-line)" strokeWidth="1.5" />

        {/* Right penalty area */}
        <rect x="940" y="165" width="180" height="420" fill="none" stroke="var(--pitch-line)" strokeWidth="1.5" />
        <rect x="1060" y="270" width="60" height="210" fill="none" stroke="var(--pitch-line)" strokeWidth="1.5" />
        <circle cx="1050" cy="375" r="4" fill="var(--primary)" opacity="0.5" />
        <path d="M 1060 165 Q 1120 240 1120 375 Q 1120 510 1060 585" fill="none" stroke="var(--pitch-line)" strokeWidth="1.5" />

        {/* Pass lines with animated dots */}
        {passLines.map((line, i) => {
          const isGreenLine = i === 2 || i === 5
          const lineColor = isGreenLine ? '#2ECC71' : 'var(--primary)'
          const dotColor = isGreenLine ? '#2ECC71' : 'var(--primary-bright)'
          return (
            <g key={line.id}>
              <line
                x1={line.x1}
                y1={line.y1}
                x2={line.x2}
                y2={line.y2}
                stroke={isGreenLine ? 'rgba(46,204,113,0.4)' : lineColor}
                strokeWidth="1.5"
                strokeDasharray="8 5"
                opacity={isGreenLine ? '0.5' : '0.3'}
                id={`pass-line-${line.id}`}
              />
              <circle
                r="4"
                fill={dotColor}
                opacity="0.9"
                style={{
                  filter: isGreenLine ? 'drop-shadow(0 0 6px rgba(46,204,113,0.6))' : 'drop-shadow(0 0 6px rgba(59,167,240,0.6))',
                }}
              >
                <animateMotion dur={`${3 + i * 0.8}s`} repeatCount="indefinite" begin={`${i * 0.5}s`}>
                  <mpath href={`#pass-line-${line.id}`} />
                </animateMotion>
              </circle>
            </g>
          )
        })}

        {/* Team A (Blue) */}
        {teamA.map((pos, i) => {
          const dotId = `a-${i}`
          const offset = dotOffsets[dotId] || { x: 0, y: 0 }
          const isDragging = draggedDot === dotId
          return (
            <circle
              key={dotId}
              cx={pos.x}
              cy={pos.y}
              r="7"
              fill="var(--dot-a)"
              className={`player-dot ${isDragging ? 'dragging' : ''}`}
              onPointerDown={(e) => handleDotPointerDown(dotId, e)}
              style={{
                filter: 'drop-shadow(0 0 6px var(--primary))',
                animation: isDragging ? 'none' : `drift-${(i % 22) + 1} ${7 + (i % 8)}s ease-in-out infinite alternate`,
                animationDelay: `${i * 0.2}s`,
                transform: `translate(${offset.x}px, ${offset.y}px)`,
                transition: isDragging ? 'none' : 'transform 600ms cubic-bezier(0.34, 1.56, 0.64, 1)',
                cursor: 'grab',
              }}
            />
          )
        })}

        {/* Team B (Gray) */}
        {teamB.map((pos, i) => {
          const dotId = `b-${i}`
          const offset = dotOffsets[dotId] || { x: 0, y: 0 }
          const isDragging = draggedDot === dotId
          return (
            <circle
              key={dotId}
              cx={pos.x}
              cy={pos.y}
              r="6"
              fill="var(--dot-b)"
              className={`player-dot ${isDragging ? 'dragging' : ''}`}
              onPointerDown={(e) => handleDotPointerDown(dotId, e)}
              style={{
                animation: isDragging ? 'none' : `drift-${((i + 11) % 22) + 1} ${8 + (i % 7)}s ease-in-out infinite alternate`,
                animationDelay: `${(i + 11) * 0.2}s`,
                transform: `translate(${offset.x}px, ${offset.y}px)`,
                transition: isDragging ? 'none' : 'transform 600ms cubic-bezier(0.34, 1.56, 0.64, 1)',
                cursor: 'grab',
              }}
            />
          )
        })}


      </svg>

      {/* Main Content Container */}
      <div
        style={{
          position: 'relative',
          zIndex: 10,
          width: '100%',
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* ZONE 1: Top Bar */}
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            height: '64px',
            padding: '0 32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            zIndex: 50,
            background: theme === 'light' ? 'rgba(237,243,255,0.85)' : 'rgba(10, 16, 32, 0.6)',
            backdropFilter: 'blur(12px)',
            borderBottom: theme === 'light' ? '1px solid rgba(31,60,136,0.1)' : 'none',
          }}
        >
          {/* Logo + Wordmark */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            {/* Football with neural network SVG */}
            <svg width="26" height="26" viewBox="0 0 26 26" fill="none" style={{ flexShrink: 0 }}>
              <circle cx="13" cy="13" r="12" stroke="#1F3C88" strokeWidth="1.5" fill="rgba(31,60,136,0.15)" />
              <polygon points="13,4 17,9 15,15 11,15 9,9" fill="none" stroke="#1F3C88" strokeWidth="1" />
              <circle cx="13" cy="4" r="1.8" fill="#3BA7F0" />
              <circle cx="17" cy="9" r="1.8" fill="#3BA7F0" />
              <circle cx="15" cy="15" r="1.8" fill="#2ECC71" />
              <circle cx="11" cy="15" r="1.8" fill="#2ECC71" />
              <circle cx="9" cy="9" r="1.8" fill="#3BA7F0" />
              <line x1="13" y1="4" x2="17" y2="9" stroke="#3BA7F0" strokeWidth="0.8" opacity="0.6" />
              <line x1="17" y1="9" x2="15" y2="15" stroke="#3BA7F0" strokeWidth="0.8" opacity="0.6" />
              <line x1="15" y1="15" x2="11" y2="15" stroke="#2ECC71" strokeWidth="0.8" opacity="0.6" />
              <line x1="11" y1="15" x2="9" y2="9" stroke="#3BA7F0" strokeWidth="0.8" opacity="0.6" />
              <line x1="9" y1="9" x2="13" y2="4" stroke="#3BA7F0" strokeWidth="0.8" opacity="0.6" />
            </svg>

            {/* Wordmark */}
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '0px', fontFamily: 'var(--font-dm-sans)', fontSize: '20px', fontWeight: 700, letterSpacing: '-0.5px' }}>
              <span style={{ color: 'var(--deep)' }}>Ball</span>
              <span style={{ color: 'var(--primary)' }}>Knowledge</span>
            </div>
          </div>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              background: theme === 'light' ? '#FFFFFF' : 'var(--surface)',
              opacity: 0.8,
              border: theme === 'light' ? '1px solid rgba(31,60,136,0.2)' : '1px solid var(--border)',
              backdropFilter: 'blur(8px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              color: theme === 'light' ? '#1F3C88' : 'var(--primary)',
              transition: 'all 300ms ease',
              padding: 0,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'var(--primary-dim)'
              e.currentTarget.style.borderColor = 'var(--primary)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'var(--surface)'
              e.currentTarget.style.borderColor = 'var(--border)'
            }}
          >
            {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
          </button>
        </div>

        {/* ZONE 2: Main Content */}
        <div
          style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '80px 24px 48px 24px',
            gap: 0,
            overflow: 'visible',
          }}
        >
          <div
            style={{
              maxWidth: '580px',
              width: '100%',
              margin: '0 auto',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
            }}
          >
            {/* Badge */}
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '6px 14px 6px 10px',
                background: theme === 'light' ? 'rgba(31,60,136,0.08)' : 'rgba(59,167,240,0.08)',
                border: theme === 'light' ? '1px solid rgba(31,60,136,0.2)' : '1px solid rgba(59,167,240,0.2)',
                borderRadius: '6px',
                marginBottom: '12px',
                alignSelf: 'center',
              }}
            >
              <div
                className="badge-indicator"
                style={{
                  width: '9px',
                  height: '9px',
                  borderRadius: '50%',
                  background: 'var(--green)',
                }}
              />
              <span style={{ fontFamily: 'var(--font-dm-sans)', fontSize: '11px', fontWeight: 600, letterSpacing: '0.1em', color: theme === 'light' ? '#1F3C88' : 'var(--primary)' }}>
                COMING SOON
              </span>
            </div>

            {/* Headline */}
            <div style={{ textAlign: 'center', marginBottom: '10px', lineHeight: '0.92', position: 'relative', width: '100%' }}>
              <div
                style={{
                  fontFamily: 'var(--font-barlow-condensed)',
                  fontWeight: 900,
                  fontSize: 'clamp(44px, 5vw, 72px)',
                  color: theme === 'light' ? '#0A1428' : 'var(--text)',
                  display: 'block',
                }}
              >
                THE GAME
              </div>
              <div style={{ position: 'relative' }}>
                <div
                  style={{
                    fontFamily: 'var(--font-barlow-condensed)',
                    fontWeight: 900,
                    fontSize: 'clamp(48px, 5.5vw, 76px)',
                    color: theme === 'light' ? '#1F3C88' : 'var(--primary)',
                    display: 'block',
                    position: 'relative',
                    zIndex: 2,
                    textShadow: theme === 'dark' ? '0 0 30px rgba(59,167,240,0.6), 0 0 60px rgba(59,167,240,0.3), 0 0 100px rgba(59,167,240,0.15)' : '0 0 20px rgba(31,60,136,0.3), 0 0 40px rgba(31,60,136,0.15)',
                    animation: theme === 'dark' ? 'decoded-glow 3s ease-in-out infinite' : 'none',
                  }}
                >
                  DECODED
                </div>
                <div
                  style={{
                    position: 'absolute',
                    top: '-10%',
                    left: '-10%',
                    width: '120%',
                    height: '120%',
                    background: `radial-gradient(ellipse at center, var(--primary-glow) 0%, transparent 65%)`,
                    filter: 'blur(20px)',
                    zIndex: 1,
                    animation: 'glow-breathe 4s ease-in-out infinite',
                    borderRadius: '50%',
                  }}
                />
              </div>
            </div>

            {/* Subheadline */}
            <p
              style={{
                fontFamily: 'var(--font-dm-sans)',
                fontSize: '14px',
                fontWeight: 400,
                color: 'var(--muted)',
                textAlign: 'center',
                lineHeight: '1.55',
                maxWidth: '400px',
                margin: '0 auto 16px auto',
              }}
            >
              Real-time football strategy analysis powered by neural networks and large language models. Tactical intelligence as the game unfolds.
            </p>

            {/* Email Form */}
            <form
              onSubmit={handleSubmit}
              style={{
                width: '100%',
                maxWidth: '460px',
                margin: '0 auto 18px auto',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  height: '48px',
                  gap: 0,
                }}
              >
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    setEmailError('')
                  }}
                  placeholder="Enter your email"
                  disabled={emailSuccess || isSubmitting}
                  style={{
                    flex: 1,
                    height: '52px',
                    padding: '0 20px',
                    background: 'var(--surface)',
                    border: emailError && !emailError.includes('Already') ? '1px solid #F87171' : '1px solid var(--border)',
                    borderRight: 'none',
                    borderRadius: '28px 0 0 28px',
                    fontFamily: 'var(--font-dm-sans)',
                    fontSize: '14px',
                    color: 'var(--text)',
                    outline: 'none',
                    transition: 'all 300ms ease',
                    opacity: emailSuccess ? 0.6 : 1,
                    cursor: emailSuccess ? 'default' : 'text',
                  }}
                  onFocus={(e) => {
                    if (!emailError && !emailSuccess) {
                      e.currentTarget.style.borderColor = 'var(--primary)'
                      e.currentTarget.style.boxShadow = '0 0 0 3px var(--primary-glow)'
                    }
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.boxShadow = 'none'
                    if (!emailError) {
                      e.currentTarget.style.borderColor = 'var(--border)'
                    }
                  }}
                />
                <button
                  type="submit"
                  disabled={emailSuccess || isSubmitting}
                  className="button-shimmer"
                  style={{
                    position: 'relative',
                    width: '140px',
                    height: '48px',
                    background: emailSuccess ? 'var(--deep)' : `linear-gradient(135deg, var(--primary) 0%, var(--deep) 100%)`,
                    border: 'none',
                    borderRadius: '0 28px 28px 0',
                    fontFamily: 'var(--font-dm-sans)',
                    fontWeight: 600,
                    fontSize: '14px',
                    color: '#FFFFFF',
                    cursor: emailSuccess || isSubmitting ? 'default' : 'pointer',
                    letterSpacing: '0.03em',
                    transition: 'all 300ms ease',
                    opacity: emailSuccess ? 0.6 : 1,
                    overflow: 'hidden',
                  }}
                  onMouseEnter={(e) => {
                    if (!emailSuccess && !isSubmitting) {
                      e.currentTarget.style.filter = 'brightness(1.12)'
                      e.currentTarget.style.transform = 'scale(1.02)'
                    }
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.filter = 'brightness(1)'
                    e.currentTarget.style.transform = 'scale(1)'
                  }}
                >
                  {emailSuccess ? (
                    <span style={{ display: 'flex', alignItems: 'center', gap: '6px', justifyContent: 'center' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M20 6L9 17l-5-5" />
                      </svg>
                      You&apos;re in
                    </span>
                  ) : (
                    'Get Early Access'
                  )}
                </button>
              </div>
              {emailError && (
                <div style={{ fontSize: '12px', color: emailError.includes('Already') ? 'var(--primary)' : '#F87171', textAlign: 'center', marginTop: '8px', fontFamily: 'var(--font-dm-sans)' }}>
                  {emailError}
                </div>
              )}
            </form>

            {/* Gradient divider rule */}
            <div
              style={{
                width: '100%',
                maxWidth: '460px',
                height: '1px',
                background: theme === 'light'
                  ? 'linear-gradient(90deg, transparent, rgba(31,60,136,0.2), rgba(46,204,113,0.2), transparent)'
                  : 'linear-gradient(90deg, transparent, rgba(46,204,113,0.3), rgba(59,167,240,0.3), transparent)',
                margin: '0 auto 18px auto',
              }}
            />

            {/* Countdown */}
            <div style={{ width: '100%', maxWidth: '460px', margin: '0 auto 16px auto', textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-dm-sans)', fontSize: '10px', fontWeight: 600, letterSpacing: '0.14em', color: theme === 'light' ? '#27AE60' : '#2ECC71', marginBottom: '12px', display: 'block' }}>
                LAUNCHING IN
              </div>
              <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', gap: '16px' }}>
              {[
                { label: 'DAYS', value: countdown.days },
                { label: 'HOURS', value: countdown.hours },
                { label: 'MINUTES', value: countdown.minutes },
                { label: 'SECONDS', value: countdown.seconds },
              ].map((item, i) => {
                const isGreenItem = i >= 2
                return (
                  <div
                    key={i}
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '6px',
                      minWidth: '64px',
                    }}
                  >
                    <div
                      style={{
                        fontFamily: 'var(--font-barlow-condensed)',
                        fontWeight: 900,
                        fontSize: 'clamp(36px, 4.5vw, 56px)',
                        color: theme === 'light' 
                          ? (isGreenItem ? '#27AE60' : '#1F3C88') 
                          : (isGreenItem ? '#2ECC71' : 'var(--primary)'),
                        lineHeight: 1,
                        textShadow: theme === 'light'
                          ? (isGreenItem ? '0 0 16px rgba(39,174,96,0.2)' : '0 0 16px rgba(31,60,136,0.2)')
                          : (isGreenItem ? '0 0 24px rgba(46,204,113,0.4)' : '0 0 24px var(--primary-glow)'),
                      }}
                    >
                      {String(item.value).padStart(2, '0')}
                    </div>
                    <div style={{ fontFamily: 'var(--font-dm-sans)', fontSize: '10px', fontWeight: 500, letterSpacing: '0.1em', color: 'var(--muted)', textTransform: 'uppercase' }}>
                      {item.label}
                    </div>
                  </div>
                )
              })}
              </div>
            </div>

            {/* Feature Chips */}
            <div style={{ display: 'flex', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: '8px', marginBottom: 0 }}>
              {[
                { text: 'Computer Vision Pipeline', Icon: Eye },
                { text: 'LLM Tactical Analysis', Icon: Brain },
                { text: 'Real-Time Processing', Icon: Zap },
              ].map((chip, i) => {
                const Icon = chip.Icon
                const borderColors = ['#3BA7F0', 'rgba(46,204,113,0.4)', '#3BA7F0']
                const iconColors = theme === 'light' 
                  ? ['#1F3C88', '#27AE60', '#1F3C88']
                  : ['#3BA7F0', '#2ECC71', '#3BA7F0']
                return (
                  <div
                    key={i}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '6px 13px',
                      background: theme === 'light' ? 'rgba(31,60,136,0.06)' : 'rgba(59,167,240,0.06)',
                      border: theme === 'light' ? `1px solid rgba(31,60,136,0.15)` : `1px solid rgba(59,167,240,0.14)`,
                      borderLeft: `2px solid ${theme === 'light' ? (i === 1 ? 'rgba(46,204,113,0.4)' : '#1F3C88') : borderColors[i]}`,
                      borderRadius: '999px',
                      fontFamily: 'var(--font-dm-sans)',
                      fontSize: '11px',
                      fontWeight: 500,
                      color: 'var(--muted)',
                      transition: 'all 300ms ease',
                      cursor: 'pointer',
                    }}
                    onMouseEnter={(e) => {
                      const bg = theme === 'light' ? 'rgba(31,60,136,0.12)' : 'rgba(59,167,240,0.1)'
                      const border = theme === 'light' ? '#1F3C88' : 'var(--primary)'
                      const text = theme === 'light' ? '#0A1428' : 'var(--text)'
                      e.currentTarget.style.borderColor = border
                      e.currentTarget.style.color = text
                      e.currentTarget.style.background = bg
                    }}
                    onMouseLeave={(e) => {
                      const bg = theme === 'light' ? 'rgba(31,60,136,0.06)' : 'rgba(59,167,240,0.06)'
                      const border = theme === 'light' ? 'rgba(31,60,136,0.15)' : 'var(--border)'
                      const text = 'var(--muted)'
                      e.currentTarget.style.borderColor = border
                      e.currentTarget.style.color = text
                      e.currentTarget.style.background = bg
                    }}
                  >
                    <Icon size={16} style={{ color: iconColors[i] }} />
                    {chip.text}
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* ZONE 3: Footer Bar */}
        <div
          style={{
            height: '56px',
            flexShrink: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '16px',
            background: 'transparent',
          }}
        >
          {[
            { icon: Github, href: 'https://github.com' },
            { icon: Linkedin, href: 'https://linkedin.com' },
          ].map((link, i) => {
            const Icon = link.icon
            return (
              <a
                key={i}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  width: '38px',
                  height: '38px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: theme === 'light' ? 'rgba(31,60,136,0.06)' : 'var(--surface)',
                  opacity: 0.7,
                  border: theme === 'light' ? '1px solid rgba(31,60,136,0.15)' : '1px solid var(--border)',
                  backdropFilter: 'blur(8px)',
                  color: theme === 'light' ? '#6B7A99' : 'var(--muted)',
                  cursor: 'pointer',
                  transition: 'all 300ms ease',
                  textDecoration: 'none',
                }}
                onMouseEnter={(e) => {
                  if (theme === 'light') {
                    e.currentTarget.style.borderColor = '#1F3C88'
                    e.currentTarget.style.color = '#1F3C88'
                    e.currentTarget.style.background = 'rgba(31,60,136,0.12)'
                  } else {
                    e.currentTarget.style.borderColor = 'var(--primary)'
                    e.currentTarget.style.color = 'var(--primary)'
                    e.currentTarget.style.background = 'var(--primary-dim)'
                  }
                }}
                onMouseLeave={(e) => {
                  if (theme === 'light') {
                    e.currentTarget.style.borderColor = 'rgba(31,60,136,0.15)'
                    e.currentTarget.style.color = '#6B7A99'
                    e.currentTarget.style.background = 'rgba(31,60,136,0.06)'
                  } else {
                    e.currentTarget.style.borderColor = 'var(--border)'
                    e.currentTarget.style.color = 'var(--muted)'
                    e.currentTarget.style.background = 'var(--surface)'
                  }
                }}
              >
                <Icon size={18} />
              </a>
            )
          })}
        </div>

        {/* Footer ground glow */}
        <div
          style={{
            position: 'fixed',
            bottom: 0,
            left: 0,
            right: 0,
            height: '120px',
            background: theme === 'light'
              ? 'linear-gradient(to top, rgba(46, 204, 113, 0.07), transparent)'
              : 'linear-gradient(to top, rgba(46, 204, 113, 0.09), transparent)',
            pointerEvents: 'none',
            zIndex: 5,
          }}
        />
      </div>
    </div>
  )
}

export default BallKnowledge
